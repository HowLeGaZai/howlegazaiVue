<template>
    <header>
      <nav class="main">
        <div class="leftnav">
          <!-- 登入後 -->
          <button class="burger" id="burger"><i class="bi bi-list"></i></button>
          <!-- logo -->
          <a class="brand" href="./index.html">
            <img src="./img/logo.svg" alt="" />
          </a>
          <div class="nav-back" id="nav-back">
            <ul id="main-Menu">
              <li class="left-logo"><img src="./img/logo2.svg" alt="" /></li>
              <li>
                <!-- <a href="./contact.html">聯絡里辦</a> -->
                <router-link :to="{name:'contact'}">聯絡里辦</router-link>
              </li>
              <li>
                <a href="./news.html">最新消息</a>
              </li>
              <li>
                <a href="./chat.html">討論區</a>
              </li>
              <li class="smart-service">
                <a href="#" id="navbarDropdown">
                  智慧里民<span><i class="bi bi-chevron-down"></i></span>
                </a>
                <ul class="dropdown-menu" id="dropdown-menu">
                  <li><a class="dropdown-item" href="">活動報名</a></li>
                  <li><a class="dropdown-item" href="">空間預約</a></li>
                  <li><a class="dropdown-item" href="#">里民團購</a></li>
                  <li><a class="dropdown-item" href="#">守望相助</a></li>
                  <li><a class="dropdown-item" href="#">維修通報</a></li>
                  <li><a class="dropdown-item" href="#">瓦斯錶回報</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
<!-- <router-view></router-view> -->
        <div class="rightnav">
          <button type="button" class="btn rad-2 font-1 color-green">
            登入 / 註冊
          </button>
          <ul>
            <li>
              <!-- 會員姓名 -->
              <p>歡迎 <span>Edison Chang</span></p>
              <!-- 會員大頭貼 -->
              <a href="#" class="userbtn tooltip" id="userBtn">
                <img src="./img/user_pic.png" alt="" class="user_pic" />
              </a>
              <div id="navMenu">
                <ul class="account-menu" id="accountMenu">
                  <li>
                    <i class="bi bi-x-lg close" id="menuClose"></i>
                  </li>
                  <li class="user">
                    <!-- 會員姓名 -->
                    <p><span>Edison Chang</span></p>
                    <!-- 會員大頭貼 -->
                    <a href="#" class="userbtn">
                      <img src="./img/user_pic.png" alt="" class="user_pic" />
                    </a>
                  </li>
                  <li><a href="#">個人資訊</a></li>
                  <li><a href="#">成員管理</a></li>
                  <li class="user-record">
                    <a href="#"
                      >管理紀錄
                      <i class="bi bi-chevron-down bi-rotate"></i>
                    </a>
                    <ul class="dropdown-menu">
                      <li>
                        <a class="dropdown-item" href="#">貼文刊登紀錄</a>
                      </li>
                      <!-- <li><a class="dropdown-item" href="#">瓦斯錶回報紀錄</a></li> -->
                      <li>
                        <a class="dropdown-item" href="#">空間預約紀錄</a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">活動報名紀錄</a>
                      </li>
                    </ul>
                  </li>
                  <!-- <li><a class="dropdown-item" href="#">團購管理</a></li> -->
                  <li><hr class="dropdown-line" /></li>
                  <li>
                    <a href="#">變更密碼</a>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </header>

    <main class="home">
      
        <!-- 村里封面照片 -->
      <section class="home-cover">
          <div class="image home_banner">
            <img src="./img/home_banner.jpg" alt="" />
            <div class="villagename"><h1>花蓮縣 大湖里</h1></div>
        </div>
      </section>

      <!-- 最新消息 -->
      <section class="home-news">
        <h1 class="title_space">最新消息</h1>
        <table>
          <thead>
            <tr>
              <th>標題</th>
              <th>發布日期</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <div class="tag tag-pink">藝文
                </div><a href="#">大湖里反詐騙宣導</a></td>
              <td>2022-01-01</td>
            </tr>
            <tr>
              <td>
                <div class="tag tag-orange">公告
                </div><a href="#">大湖里112年3月21日(二)實施病媒蚊消毒噴灑作業</a></td>
              <td class="table_right">2022-01-01</td>
            </tr>
            <tr>
              <td>
                <div class="tag tag-blue">經費報告
                </div><a href="#">大湖里睦鄰互助聯誼活動補助費計畫表</a></td>
              <td class="table_right">2022-01-01</td>
            </tr>
            <tr>
              <td>
                <div class="tag tag-orange">公告
                </div><a href="#">大湖里112年3月21日(二)實施病媒蚊消毒噴灑作業</a></td>
              <td class="table_right">2022-01-01</td>
            </tr>
            <tr>
              <td>
                <div class="tag tag-orange">公告</div>
                <a href="#">大湖里112年3月21日(二)實施病媒蚊消毒噴灑作業</a></td>
              
              <td class="table_right">2022-01-01</td>
            </tr>
          </tbody>
        </table>
      </section>

      <!-- 活動 -->
      <section class="home-event">
        <h1 class="title_space">活動資訊</h1>

        <!-- Swiper -->
        <div class="swiper mySwiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="card">
                <img
                  class="image event_pic"
                  src="./img/e1_calligraphy.png"
                  alt=""
                />
                <div class="tag tag-pink card-tag">藝文</div>
                <div class="card-line"></div>
                <div class="">
                  <h3 class="card-title">新春書法體驗課</h3>
                  <!-- <div class="card-person">
                            <div class="image user_pic">
                                <img src="./img/user_pic.png" alt="">
                            </div>
                            <p>Emma</p>
                        </div> -->

                  <!-- <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p> -->
                  <h5 class="card-date">活動日期：<span>2023-01-01</span></h5>
                  <h3 class="card-price">免費</h3>
                  <a class="card-link" href="#"
                    ><h5>活動詳情<i class="bi bi-arrow-right"></i></h5
                  ></a>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="card">
                <img
                  class="image event_pic"
                  src="./img/e1_calligraphy.png"
                  alt=""
                />
                <div class="tag tag-pink card-tag">藝文</div>
                <div class="card-line"></div>
                <div class="">
                  <h3 class="card-title">新春書法體驗課</h3>
                  <!-- <div class="card-person">
                            <div class="image user_pic">
                                <img src="./img/user_pic.png" alt="">
                            </div>
                            <p>Emma</p>
                        </div> -->

                  <!-- <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p> -->
                  <h5 class="card-date">活動日期：<span>2023-01-01</span></h5>
                  <h3 class="card-price">免費</h3>
                  <a class="card-link" href="#"
                    ><h5>活動詳情<i class="bi bi-arrow-right"></i></h5
                  ></a>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="card">
                <img
                  class="image event_pic"
                  src="./img/e1_calligraphy.png"
                  alt=""
                />
                <div class="tag tag-pink card-tag">藝文</div>
                <div class="card-line"></div>
                <div class="">
                  <h3 class="card-title">新春書法體驗課</h3>
                  <!-- <div class="card-person">
                            <div class="image user_pic">
                                <img src="./img/user_pic.png" alt="">
                            </div>
                            <p>Emma</p>
                        </div> -->

                  <!-- <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p> -->
                  <h5 class="card-date">活動日期：<span>2023-01-01</span></h5>
                  <h3 class="card-price">免費</h3>
                  <a class="card-link" href="#"
                    ><h5>活動詳情<i class="bi bi-arrow-right"></i></h5
                  ></a>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="card">
                <img
                  class="image event_pic"
                  src="./img/e1_calligraphy.png"
                  alt=""
                />
                <div class="tag tag-pink card-tag">藝文</div>
                <div class="card-line"></div>
                <div class="">
                  <h3 class="card-title">新春書法體驗課</h3>
                  <!-- <div class="card-person">
                            <div class="image user_pic">
                                <img src="./img/user_pic.png" alt="">
                            </div>
                            <p>Emma</p>
                        </div> -->

                  <!-- <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p> -->
                  <h5 class="card-date">活動日期：<span>2023-01-01</span></h5>
                  <h3 class="card-price">免費</h3>
                  <a class="card-link" href="#"
                    ><h5>活動詳情<i class="bi bi-arrow-right"></i></h5
                  ></a>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="card">
                <img
                  class="image event_pic"
                  src="./img/e1_calligraphy.png"
                  alt=""
                />
                <div class="tag tag-pink card-tag">藝文</div>
                <div class="card-line"></div>
                <div class="">
                  <h3 class="card-title">新春書法體驗課</h3>
                  <!-- <div class="card-person">
                            <div class="image user_pic">
                                <img src="./img/user_pic.png" alt="">
                            </div>
                            <p>Emma</p>
                        </div> -->

                  <!-- <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p> -->
                  <h5 class="card-date">活動日期：<span>2023-01-01</span></h5>
                  <h3 class="card-price">免費</h3>
                  <a class="card-link" href="#"
                    ><h5>活動詳情<i class="bi bi-arrow-right"></i></h5
                  ></a>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="card">
                <img
                  class="image event_pic"
                  src="./img/e1_calligraphy.png"
                  alt=""
                />
                <div class="tag tag-pink card-tag">藝文</div>
                <div class="card-line"></div>
                <div class="">
                  <h3 class="card-title">新春書法體驗課</h3>
                  <!-- <div class="card-person">
                            <div class="image user_pic">
                                <img src="./img/user_pic.png" alt="">
                            </div>
                            <p>Emma</p>
                        </div> -->

                  <!-- <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p> -->
                  <h5 class="card-date">活動日期：<span>2023-01-01</span></h5>
                  <h3 class="card-price">免費</h3>
                  <a class="card-link" href="#"
                    ><h5>活動詳情<i class="bi bi-arrow-right"></i></h5
                  ></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-button">
          <button type="button" class="btn-cir-m  btn-color-white swiper-button-prev"><i class="bi bi-caret-left-fill"></i></button>
          <button type="button" class="btn-cir-m btn-color-green swiper-button-next"><i class="bi bi-caret-right-fill"></i></button>
        </div>
    </section>

          <!-- 討論區 -->
          <section class="home-chat">
            <h1 class="title_space">討論區</h1>
            <article class="">
              <section>
                  <section class="chat_news ">
                      <div>
                          <div class="image user_pic">
                              <img src="./img/user_pic.png" alt="">
                          </div>
                          <h5>櫻桃爺爺<span>5小時前</span></h5>
                      </div>
                      <h2>最近吃到大湖里超好吃飯糰</h2>
                      <p>大湖里出產的飯糰米粒粒粒分明，調味也很好吃。超級好吃，100分的大湖里早餐</p>
                      <div class="tag tag-pink">美食討論</div>
                  </section>
                  <div class="image list_pic">
                      <img src="./img/c_1_food.jpg" alt="">
                  </div>
              </section>
            </article>
            <article class="">
              <section>
                  <section class="chat_news ">
                      <div>
                          <div class="image user_pic">
                              <img src="./img/user_pic.png" alt="">
                          </div>
                          <h5>櫻桃爺爺<span>5小時前</span></h5>
                      </div>
                      <h2>最近吃到大湖里超好吃飯糰</h2>
                      <p>大湖里出產的飯糰米粒粒粒分明，調味也很好吃。超級好吃，100分的大湖里早餐</p>
                      <div class="tag tag-pink">美食討論</div>
                  </section>
                  <div class="image list_pic">
                      <img src="./img/c_1_food.jpg" alt="">
                  </div>
              </section>
            </article>

          </section>

          <!-- 團購區 -->
          <section class="home-product">
            <h1 class="title_space">團購區</h1>
            <!-- Swiper -->
        <div class="swiper mySwiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="card">
                <img class="image event_pic" src="./img/p1_cherry.jpg" alt="">
                <div class="tag tag-round tag-blue card-tag">食品</div>
                <div class="card-line"></div>
                <div class="">
                    <h3 class="card-title">櫻桃妹子團購</h3>
                    <div class="card-person">
                        <div class="image user_pic">
                            <img src="./img/user_pic.png" alt="">
                        </div>
                        <p>Emma</p>
                    </div>
                  
                    <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p>
                    <h5 class="card-date">團購截止日期：<span>2023-01-01</span></h5>
                    <h3 class="card-price">100/盒</h3>
                    <a class="card-link" href="#"><h5> 商品詳情<i class="bi bi-arrow-right"></i></h5></a>
                </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card">
              <img class="image event_pic" src="./img/p1_cherry.jpg" alt="">
              <div class="tag tag-round tag-blue card-tag">食品</div>
              <div class="card-line"></div>
              <div class="">
                  <h3 class="card-title">櫻桃妹子團購</h3>
                  <div class="card-person">
                      <div class="image user_pic">
                          <img src="./img/user_pic.png" alt="">
                      </div>
                      <p>Emma</p>
                  </div>
                
                  <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p>
                  <h5 class="card-date">團購截止日期：<span>2023-01-01</span></h5>
                  <h3 class="card-price">100/盒</h3>
                  <a class="card-link" href="#"><h5> 商品詳情<i class="bi bi-arrow-right"></i></h5></a>
              </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="card">
            <img class="image event_pic" src="./img/p1_cherry.jpg" alt="">
            <div class="tag tag-round tag-blue card-tag">食品</div>
            <div class="card-line"></div>
            <div class="">
                <h3 class="card-title">櫻桃妹子團購</h3>
                <div class="card-person">
                    <div class="image user_pic">
                        <img src="./img/user_pic.png" alt="">
                    </div>
                    <p>Emma</p>
                </div>
              
                <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p>
                <h5 class="card-date">團購截止日期：<span>2023-01-01</span></h5>
                <h3 class="card-price">100/盒</h3>
                <a class="card-link" href="#"><h5> 商品詳情<i class="bi bi-arrow-right"></i></h5></a>
            </div>
        </div>
      </div>
      <div class="swiper-slide">
        <div class="card">
          <img class="image event_pic" src="./img/p1_cherry.jpg" alt="">
          <div class="tag tag-round tag-blue card-tag">食品</div>
          <div class="card-line"></div>
          <div class="">
              <h3 class="card-title">櫻桃妹子團購</h3>
              <div class="card-person">
                  <div class="image user_pic">
                      <img src="./img/user_pic.png" alt="">
                  </div>
                  <p>Emma</p>
              </div>
            
              <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p>
              <h5 class="card-date">團購截止日期：<span>2023-01-01</span></h5>
              <h3 class="card-price">100/盒</h3>
              <a class="card-link" href="#"><h5> 商品詳情<i class="bi bi-arrow-right"></i></h5></a>
          </div>
      </div>
    </div>
    <div class="swiper-slide">
      <div class="card">
        <img class="image event_pic" src="./img/p1_cherry.jpg" alt="">
        <div class="tag tag-round tag-blue card-tag">食品</div>
        <div class="card-line"></div>
        <div class="">
            <h3 class="card-title">櫻桃妹子團購</h3>
            <div class="card-person">
                <div class="image user_pic">
                    <img src="./img/user_pic.png" alt="">
                </div>
                <p>Emma</p>
            </div>
          
            <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p>
            <h5 class="card-date">團購截止日期：<span>2023-01-01</span></h5>
            <h3 class="card-price">100/盒</h3>
            <a class="card-link" href="#"><h5> 商品詳情<i class="bi bi-arrow-right"></i></h5></a>
        </div>
    </div>
  </div>
  <div class="swiper-slide">
    <div class="card">
      <img class="image event_pic" src="./img/p1_cherry.jpg" alt="">
      <div class="tag tag-round tag-blue card-tag">食品</div>
      <div class="card-line"></div>
      <div class="">
          <h3 class="card-title">櫻桃妹子團購</h3>
          <div class="card-person">
              <div class="image user_pic">
                  <img src="./img/user_pic.png" alt="">
              </div>
              <p>Emma</p>
          </div>
        
          <p class="card-content">櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺櫻桃爺爺</p>
          <h5 class="card-date">團購截止日期：<span>2023-01-01</span></h5>
          <h3 class="card-price">100/盒</h3>
          <a class="card-link" href="#"><h5> 商品詳情<i class="bi bi-arrow-right"></i></h5></a>
      </div>
  </div>
</div>
</div>
</div>
        <div class="swiper-button">
          <button type="button" class="btn-cir-m  btn-color-white swiper-button-prev"><i class="bi bi-caret-left-fill"></i></button>
          <button type="button" class="btn-cir-m btn-color-green swiper-button-next"><i class="bi bi-caret-right-fill"></i></button>
        </div>
    </section>

          <section class="home-smartChief">
            <h1 class="title_space">智慧里民</h1>

            <section>
              <div class="left">
                <a class="btn-s btn-color-green">維修通報</a>
                <a class="btn-s btn-color-green">活動報名</a>
                <a class="btn-s btn-color-green">瓦斯錶回報</a>
              </div>
              <div class="out-circle">
                <div class="smart_center">里民服務</div>
              </div>
              <div class="right">
                <a class="btn-s btn-color-green">團購區</a>
                <a class="btn-s btn-color-green">公設預約</a>
                <a class="btn-s btn-color-green">守望相助</a>
              </div>
            </section>

          </section>
    </main>
</template>

<script>


export default {
    data(){

    },
    methods:{

    },
    mounted(){
     
// const router = VueRouter.createRouter({
//             history: VueRouter.createWebHashHistory(),
//             // history: VueRouter.createWebHistory(),
//             // routes:[], //在哪個路徑下，render 哪一個組件
//             routes:[
//                 {path: '/', component:Home},
//                 {path: '/about', 
//                 component:About,
//                 children:[
//                     {path:`us`,component:AboutUs},
//                     {path:`others`,component:AboutOthers},
//                 ],
//             },
//                 {
//                     path: '/products/:sn?', 
//                     component:Products,
//                 },
//             ], 
//         })  

//         Vue.createApp(App).use(router).mount('#app')



let burgerBtn = document.getElementById("burger");
      let mainMenu = document.getElementById("main-Menu");
      let dropList = document.getElementById("dropdown-menu");
      let dropBtn = document.getElementById("navbarDropdown");
      let navBack = document.getElementById("nav-back");
      let userBtn = document.getElementById("userBtn");
      let navMenu = document.getElementById("navMenu");
      let accountMenu = document.getElementById("accountMenu");
      let menuClose = document.getElementById("menuClose");

      burgerBtn.onclick = function () {
        navBack.classList.add("menushow");
        mainMenu.classList.add("menushow");
      };
      navBack.onclick = function () {
        navBack.classList.remove("menushow");
        mainMenu.classList.remove("menushow");
      };

      dropBtn.onclick = function (e) {
        e.stopPropagation();
        dropList.classList.toggle("show");
        dropBtn.classList.toggle("onoff");
      };

      userBtn.onclick = function () {
        accountMenu.classList.add("accountshow");
      };

      menuClose.onclick = function () {
        accountMenu.classList.remove("accountshow");
      };
    },
}
</script>



<style>
    @import "assets/css/style.css";
</style>